

public class Main {

    
    public static void main(String[] args) {
        double initialValue = 1000.0; 
        double growthRate = 0.05;
        int years = 10; 

        
        double futureValue = calculateFutureValue(initialValue, growthRate, years);

        System.out.printf("Future Value after %d years: $%.2f%n", years, futureValue);
    }

  
    private static double calculateFutureValue(double initialValue, double growthRate, int years) {
        double futureValue = initialValue;
        for (int i = 0; i < years; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }
}
