
public class Main {
    public static void main(String[] args) {
        InventoryManager inventoryManager = new InventoryManager();

        Product product1 = new Product(1, "Laptop", 10, 799.99);
        Product product2 = new Product(2, "Smartphone", 20, 499.99);
        Product product3 = new Product(3, "Tablet", 15, 299.99);

        inventoryManager.addProduct(product1);
        inventoryManager.addProduct(product2);
        inventoryManager.addProduct(product3);

        System.out.println("Initial Inventory:");
        System.out.println(inventoryManager);

        Product updatedProduct1 = new Product(1, "Laptop", 8, 749.99);
        inventoryManager.updateProduct(updatedProduct1);

        System.out.println("\nInventory after update:");
        System.out.println(inventoryManager);

        inventoryManager.deleteProduct(2);

        System.out.println("\nInventory after deletion:");
        System.out.println(inventoryManager);

        Product retrievedProduct = inventoryManager.getProduct(3);
        System.out.println("\nRetrieved Product:");
        System.out.println(retrievedProduct);
    }
}
