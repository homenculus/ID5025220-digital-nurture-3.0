import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // Initialize books
        Book[] books = {
            new Book("B001", "To Kill a Mockingbird", "Harper Lee"),
            new Book("B002", "1984", "George Orwell"),
            new Book("B003", "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book("B004", "Moby Dick", "Herman Melville"),
            new Book("B005", "Pride and Prejudice", "Jane Austen")
        };

        // Sort the books array by title for binary search
        Arrays.sort(books, (a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()));

        // Search for a book using linear search
        String titleToSearch = "1984";
        Book result1 = LibrarySearch.linearSearch(books, titleToSearch);
        System.out.println("Linear Search Result:");
        System.out.println(result1 != null ? result1 : "Book not found");

        // Search for a book using binary search
        Book result2 = LibrarySearch.binarySearch(books, titleToSearch);
        System.out.println("\nBinary Search Result:");
        System.out.println(result2 != null ? result2 : "Book not found");
    }
}
