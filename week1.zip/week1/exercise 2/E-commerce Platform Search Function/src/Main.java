public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product("P001", "Laptop", "Electronics"),
            new Product("P002", "Smartphone", "Electronics"),
            new Product("P003", "Book", "Stationery"),
            new Product("P004", "Tablet", "Electronics"),
            new Product("P005", "Pen", "Stationery")
        };

        System.out.println("Linear Search:");
        Product result1 = SearchAlgorithms.linearSearch(products, "Tablet");
        System.out.println(result1 != null ? result1 : "Product not found");

        System.out.println("\nBinary Search:");
        Product result2 = SearchAlgorithms.binarySearch(products, "Tablet");
        System.out.println(result2 != null ? result2 : "Product not found");
    }
}
