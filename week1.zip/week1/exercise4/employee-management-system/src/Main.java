public class Main {
    public static void main(String[] args) {
        EmployeeManagement ems = new EmployeeManagement(10);

        // Add employees
        ems.addEmployee(new Employee("E001", "Alice", "Manager", 75000));
        ems.addEmployee(new Employee("E002", "Bob", "Developer", 65000));
        ems.addEmployee(new Employee("E003", "Charlie", "Analyst", 55000));

        // Search for an employee
        Employee e = ems.searchEmployee("E002");
        if (e != null) {
            System.out.println("Found: " + e);
        } else {
            System.out.println("Employee not found.");
        }

        // Traverse and print all employees
        System.out.println("\nAll Employees:");
        ems.traverseEmployees();

        // Delete an employee
        ems.deleteEmployee("E002");

        // Traverse and print all employees after deletion
        System.out.println("\nEmployees after deletion:");
        ems.traverseEmployees();
    }
}
