public class TaskLinkedList {
    private Node head;

    
    public TaskLinkedList() {
        head = null;
    }

    
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(newNode);
        }
    }

   
    public Task searchTask(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.getTask().getTaskId().equals(taskId)) {
                return current.getTask();
            }
            current = current.getNext();
        }
        return null;
    }

    
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.getTask());
            current = current.getNext();
        }
    }

   
    public void deleteTask(String taskId) {
        if (head == null) return;

        if (head.getTask().getTaskId().equals(taskId)) {
            head = head.getNext();
            return;
        }

        Node current = head;
        while (current.getNext() != null && !current.getNext().getTask().getTaskId().equals(taskId)) {
            current = current.getNext();
        }

        if (current.getNext() != null) {
            current.setNext(current.getNext().getNext());
        } else {
            System.out.println("Task not found.");
        }
    }
}
