public class Main {
    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        
        taskList.addTask(new Task("T001", "Design Homepage", "In Progress"));
        taskList.addTask(new Task("T002", "Develop API", "Not Started"));
        taskList.addTask(new Task("T003", "Write Documentation", "Completed"));

       
        System.out.println("All Tasks:");
        taskList.traverseTasks();

        
        Task task = taskList.searchTask("T002");
        System.out.println("\nSearch Result:");
        System.out.println(task != null ? task : "Task not found");

       
        taskList.deleteTask("T002");

        
        System.out.println("\nTasks after deletion:");
        taskList.traverseTasks();
    }
}
