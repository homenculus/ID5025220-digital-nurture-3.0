public class Main {
    public static void main(String[] args) {
        Logger logger1 = Logger.getInstance();
        logger1.log("Application is starting...");

        Logger logger2 = Logger.getInstance();
        logger2.log("Performing operation 1...");

        Logger logger3 = Logger.getInstance();
        logger3.log("Performing operation 2...");

        logger1.log("Application is shutting down...");

       
        System.out.println("Logger instances are the same: " + 
                            (logger1 == logger2 && logger2 == logger3));
    }
}
