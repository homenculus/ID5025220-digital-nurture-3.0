public class StrategyTest {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        PaymentStrategy creditCardPayment = new CreditCardPayment("9876543210987654", "Jane Smith", "456", "11/23");
        context.setPaymentStrategy(creditCardPayment);
        context.executePayment(10000);

        PaymentStrategy payPalPayment = new PayPalPayment("jane.smith@example.com", "securepassword");
        context.setPaymentStrategy(payPalPayment);
        context.executePayment(7000);
    }
}
