public class NotificationTest {
    public static void main(String[] args) {
        Notifier notifier = new EmailNotifier();
        Notifier smsNotifier = new SMSNotifierDecorator(notifier);
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);

        slackNotifier.send("Hello, this is a test notification!");

        Notifier smsOnlyNotifier = new SMSNotifierDecorator(new EmailNotifier());
        smsOnlyNotifier.send("This is a test for SMS and Email notification.");

      
        notifier.send("This is a test for Email notification only.");
    }
}
