public class CommandTest {
    public static void main(String[] args) {
        Light kitchenLight = new Light();

        Command lightOn = new LightOnCommand(kitchenLight);
        Command lightOff = new LightOffCommand(kitchenLight);

        RemoteControl remote = new RemoteControl();

        System.out.println("Testing kitchen light:");
        remote.setCommand(lightOn);
        remote.pressButton();

        remote.setCommand(lightOff);
        remote.pressButton();
    }
}
