public interface Observer {
    void update(String stockData);
}
