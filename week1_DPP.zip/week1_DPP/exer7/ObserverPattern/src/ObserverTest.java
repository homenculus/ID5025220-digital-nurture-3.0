public class ObserverTest {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();
        Observer mobileApp1 = new MobileApp("MobileApp1");
        Observer webApp1 = new WebApp("WebApp1");
        Observer mobileApp2 = new MobileApp("MobileApp2");

        stockMarket.registerObserver(mobileApp1);
        stockMarket.registerObserver(webApp1);
        stockMarket.registerObserver(mobileApp2);

        System.out.println("Setting stock data to AAPL: 12000 INR");
        stockMarket.setStockData("AAPL: 12000 INR");

        System.out.println("\nRemoving WebApp1 and setting stock data to GOOGL: 210000 INR");
        stockMarket.removeObserver(webApp1);
        stockMarket.setStockData("GOOGL: 210000 INR");
    }
}
